/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java_cup.runtime.Symbol;


/**
 *
 * @author maril
 */
public class Traductor {

    Traductor(LexerCup lexerCup) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    String [] transform( String [] tokens ) {
            String [] output = new String[tokens.length];
            int i = 0;
            StringBuilder sb = new StringBuilder();
            for ( String token : tokens ){
                output[i++] = sb.append(token).reverse().toString();
                sb.setLength(0);
}
            return output;
  }

    void parse() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Symbol getS() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

